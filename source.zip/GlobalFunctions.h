/*
 * GlobalFunctions.h
 *
 *  Created on: 16/08/2017
 *      Author: jlpe
 */

#ifndef GLOBALFUNCTIONS_H_
#define GLOBALFUNCTIONS_H_

#include "DataTypeDefinitions.h"

/**
 * WASTE TIME OF PROCESSOR
 */
void delay(uint16);


#endif /* GLOBALFUNCTIONS_H_ */
